var electronInstaller = require('electron-winstaller');

// In this case, we can use relative paths
var settings = {
    // Specify the folder where the built app is located
    appDirectory: './release-builds/bigstream-console-win32-ia32',
    // Specify the existing folder where 
    outputDirectory: './release-built-installers/bigstream-console-win32-ia32',
    // The name of the Author of the app (the name of your company)
    authors: 'LSR Nectec',
    // The name of the executable of your built
    exe: './bigstream-console.exe'
};

resultPromise = electronInstaller.createWindowsInstaller(settings);
 
resultPromise.then(() => {
    console.log("The installers of your application were succesfully created !");
}, (e) => {
    console.log(`Well, sometimes you are not so lucky: ${e.message}`)
});